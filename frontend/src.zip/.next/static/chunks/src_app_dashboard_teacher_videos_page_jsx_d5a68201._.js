(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_c148d27f._.js",
  "static/chunks/node_modules_2f6a4098._.js"
],
    source: "dynamic"
});
